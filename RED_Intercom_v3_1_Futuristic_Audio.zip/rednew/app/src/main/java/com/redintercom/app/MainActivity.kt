package com.redintercom.app

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.*
import android.graphics.drawable.GradientDrawable

class MainActivity : Activity() {
    private lateinit var engine: LanAudioEngine
    private lateinit var status: TextView
    private lateinit var talk: Button
    private lateinit var muteCrew: Button
    private lateinit var nameInput: EditText
    private lateinit var role: Spinner
    private lateinit var startButton: Button
    private lateinit var roleTitle: TextView
    private lateinit var speakerStatus: TextView
    private lateinit var micStatus: TextView
    private lateinit var audioGainBar: SeekBar
    private var selectedRole = "CREW"
    private var started = false
    private val prefs by lazy { getSharedPreferences("red_intercom", Context.MODE_PRIVATE) }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun rounded(color: Int, radius: Int): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(7,24,43)
        window.navigationBarColor = Color.rgb(7,24,43)
        buildUi()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 40)
    }

    private fun label(value: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false) =
        TextView(this).apply {
            text = value; textSize = size; setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(24), dp(22), dp(22))
            gravity = Gravity.CENTER_HORIZONTAL
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(2,8,18), Color.rgb(7,22,42), Color.rgb(9,35,58)))
        }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.red_logo)
            scaleType = ImageView.ScaleType.FIT_CENTER
        }
        root.addView(logo, LinearLayout.LayoutParams(dp(112), dp(78)))
        root.addView(label("RED Intercom", 29f, Color.WHITE, true))
        root.addView(label("BUILDING COMMUNICATION SYSTEM", 10f, Color.LTGRAY))
        root.addView(label("VOICE COMMUNICATION • RED SYSTEM", 11f, Color.rgb(0, 220, 255), true).apply {
            setPadding(0, dp(8), 0, dp(18))
        })

        roleTitle = label("PILIH MODE OPERASI", 13f, Color.rgb(0, 220, 255), true)
        root.addView(roleTitle)
        role = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("CREW", "OPERATOR"))
        }
        root.addView(role, LinearLayout.LayoutParams(-1, dp(48)))

        root.addView(label("IDENTITAS PERANGKAT", 12f, Color.rgb(0, 220, 255), true).apply {
            setPadding(0, dp(14), 0, dp(5))
        })
        nameInput = EditText(this).apply {
            setSingleLine(true)
            setText(prefs.getString("device_name", "Crew 01"))
            hint = "Contoh: Security / Resepsionis"
            setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
            background = rounded(Color.rgb(10, 30, 52), 18)
            setPadding(dp(14), 0, dp(14), 0)
        }
        root.addView(nameInput, LinearLayout.LayoutParams(-1, dp(52)))

        status = label("SISTEM SIAGA • TEKAN MULAI", 14f, Color.LTGRAY).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(18), 0, dp(18))
        }
        root.addView(status, LinearLayout.LayoutParams(-1, -2))
        speakerStatus = label("● TIDAK ADA YANG BERBICARA", 15f, Color.rgb(125, 190, 210), true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(12), dp(10), dp(12))
            background = rounded(Color.rgb(8, 24, 42), 16)
        }
        root.addView(speakerStatus, LinearLayout.LayoutParams(-1, dp(54)))
        micStatus = label("🎙 MIKROFON SIAGA", 13f, Color.LTGRAY, true).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(4))
        }
        root.addView(micStatus, LinearLayout.LayoutParams(-1, dp(38)))
        root.addView(label("AUDIO BOOST • GAIN OUTPUT", 12f, Color.rgb(0, 220, 255), true).apply {
            setPadding(0, dp(14), 0, dp(3))
        })
        audioGainBar = SeekBar(this).apply { max = 100; progress = 35 }
        root.addView(audioGainBar, LinearLayout.LayoutParams(-1, dp(38)))

        startButton = Button(this).apply {
            text = "MULAI INTERCOM"; isAllCaps = false
            setTextColor(Color.WHITE); background = rounded(Color.rgb(190, 12, 38), 22)
        }
        root.addView(startButton, LinearLayout.LayoutParams(-1, dp(54)))
        talk = Button(this).apply {
            text = "🎙  PTT • TEKAN & TAHAN"; isAllCaps = false
            setTextColor(Color.WHITE); textSize = 15f
            background = rounded(Color.rgb(0, 105, 235), 26)
            visibility = View.GONE
        }
        val talkParams = LinearLayout.LayoutParams(-1, dp(112))
        talkParams.topMargin = dp(18)
        root.addView(talk, talkParams)
        muteCrew = Button(this).apply {
            text = "🔇  MUTE SEMUA CREW"
            isAllCaps = false
            setTextColor(Color.WHITE)
            background = rounded(Color.rgb(165, 35, 45), 22)
            visibility = View.GONE
        }
        val muteParams = LinearLayout.LayoutParams(-1, dp(58))
        muteParams.topMargin = dp(12)
        root.addView(muteCrew, muteParams)

        root.addView(label("Operator: VOX otomatis • Diam = mute • Bicara = ON", 12f, Color.LTGRAY).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(22), 0, 0)
        })
        root.addView(label("Crew: tekan dan tahan • Lepas untuk berhenti", 12f, Color.LTGRAY).apply {
            gravity = Gravity.CENTER
        })
        setContentView(root)

        startButton.setOnClickListener {
            selectedRole = role.selectedItem.toString()
            val deviceName = nameInput.text.toString().trim().ifBlank {
                if (selectedRole == "OPERATOR") "Operator" else "Crew"
            }
            prefs.edit().putString("device_name", deviceName).apply()
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 40)
                status.text = "Izinkan akses mikrofon, lalu tekan MULAI lagi."
                return@setOnClickListener
            }
            try {
                engine = LanAudioEngine(this, selectedRole, deviceName, { message ->
                    runOnUiThread { status.text = message }
                }, { speakerName, active ->
                    runOnUiThread {
                        speakerStatus.text = if (active && speakerName.isNotBlank())
                            "● $speakerName SEDANG BERBICARA" else "● TIDAK ADA YANG BERBICARA"
                        speakerStatus.setTextColor(if (active) Color.rgb(60, 255, 150) else Color.rgb(125, 190, 210))
                    }
                }, { micActive ->
                    runOnUiThread {
                        micStatus.text = if (micActive) "🔴 MIKROFON AKTIF • MENGIRIM SUARA" else "🎙 MIKROFON SIAGA"
                        micStatus.setTextColor(if (micActive) Color.rgb(255, 70, 90) else Color.LTGRAY)
                    }
                })
                engine.setAudioGain(1.35f)
                engine.start()
                started = true
                audioGainBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                        if (started) engine.setAudioGain(1.0f + progress / 100.0f)
                    }
                    override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                    override fun onStopTrackingTouch(seekBar: SeekBar?) {}
                })
                role.isEnabled = false; nameInput.isEnabled = false; startButton.isEnabled = false
                status.text = if (selectedRole == "OPERATOR")
                    "OPERATOR AKTIF • VOX otomatis" else "$deviceName • Siap menerima dan berbicara"
                talk.visibility = if (selectedRole == "CREW") View.VISIBLE else View.GONE
                muteCrew.visibility = if (selectedRole == "OPERATOR") View.VISIBLE else View.GONE
            } catch (e: Exception) {
                status.text = "Gagal memulai: ${e.message}"
            }
        }
        var crewMuted = false
        muteCrew.setOnClickListener {
            crewMuted = !crewMuted
            engine.setCrewMutedAll(crewMuted)
            muteCrew.text = if (crewMuted) "🔊  AKTIFKAN MIC CREW" else "🔇  MUTE SEMUA CREW"
            muteCrew.background = rounded(
                if (crewMuted) Color.rgb(20, 130, 75) else Color.rgb(165, 35, 45), 22
            )
            status.text = if (crewMuted) "OPERATOR • Mikrofon semua Crew dibisukan" 
                          else "OPERATOR • Mikrofon Crew diaktifkan"
        }
        talk.setOnTouchListener { _, event ->
            if (!started) return@setOnTouchListener false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { engine.setCrewTalking(true); talk.text = "SEDANG BICARA…"; true }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    engine.setCrewTalking(false); talk.text = "🎙  PTT • TEKAN & TAHAN"; true
                }
                else -> true
            }
        }
    }

    override fun onDestroy() {
        if (started) engine.stop()
        super.onDestroy()
    }
}
