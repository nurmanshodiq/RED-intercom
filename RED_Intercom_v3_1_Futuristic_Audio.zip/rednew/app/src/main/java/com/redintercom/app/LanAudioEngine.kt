package com.redintercom.app

import android.content.Context
import android.media.*
import android.net.wifi.WifiManager
import java.net.*
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.concurrent.thread
import kotlin.math.sqrt

/**
 * RED Intercom LAN audio prototype. All devices join one router Wi-Fi network.
 * Uses UDP multicast PCM. Internet access is not needed.
 */
class LanAudioEngine(
    private val context: Context,
    private val role: String,
    private val deviceName: String,
    private val onStatus: (String) -> Unit,
    private val onSpeaker: (String, Boolean) -> Unit = { _, _ -> },
    private val onMicActivity: (Boolean) -> Unit = { _ -> }
) {
    companion object {
        private const val GROUP = "239.10.10.10"
        private const val PORT = 50005
        private const val RATE = 16000
        private const val SAMPLES = 320
        private const val MAGIC = 0x52454431
    }
    private val deviceId = java.util.UUID.randomUUID().toString().take(8)
    @Volatile private var running = false
    @Volatile private var crewTalking = false
    @Volatile private var crewMutedByOperator = false
    private var socket: MulticastSocket? = null
    private var multicastLock: WifiManager.MulticastLock? = null
    private var recorder: AudioRecord? = null
    private var player: AudioTrack? = null
    private var lastVoiceAt = 0L
    @Volatile private var lastSpeakerAt = 0L
    @Volatile private var audioGain = 1.35f

    fun start() {
        val wifi = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        multicastLock = wifi.createMulticastLock("red-intercom").apply {
            setReferenceCounted(false); acquire()
        }
        socket = MulticastSocket(PORT).apply {
            reuseAddress = true
            soTimeout = 250
            timeToLive = 1
            joinGroup(InetAddress.getByName(GROUP))
        }
        val inMin = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val outMin = AudioTrack.getMinBufferSize(RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        recorder = AudioRecord(MediaRecorder.AudioSource.VOICE_COMMUNICATION, RATE,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(inMin, SAMPLES * 8))
        player = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setSampleRate(RATE).setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(maxOf(outMin, SAMPLES * 8))
            .setTransferMode(AudioTrack.MODE_STREAM).build()
        running = true
        player?.setVolume(1.0f) // Maksimum gain AudioTrack; volume sistem HP tetap berlaku
        player?.play()
        recorder?.startRecording()
        thread(name = "RED-RX") { receiveLoop() }
        thread(name = "RED-TX") { captureLoop() }
        onStatus("Terhubung ke jaringan lokal • $deviceName")
    }

    fun setCrewTalking(active: Boolean) { crewTalking = active }

    fun setAudioGain(gain: Float) { audioGain = gain.coerceIn(1.0f, 2.0f) }

    /** Operator broadcasts a room-wide Crew microphone mute/unmute command. */
    fun setCrewMutedAll(muted: Boolean) {
        if (role != "OPERATOR") return
        val previous = crewMutedByOperator
        crewMutedByOperator = muted
        try {
            val packet = ByteBuffer.allocate(17).order(ByteOrder.BIG_ENDIAN)
            packet.putInt(MAGIC)
            packet.put(deviceId.toByteArray(Charsets.US_ASCII).copyOf(8))
            packet.put(3.toByte()) // operator control packet
            packet.put(0.toByte())
            packet.putShort(1.toShort())
            packet.put(if (muted) 1.toByte() else 0.toByte())
            val data = packet.array()
            socket?.send(DatagramPacket(data, data.size, InetAddress.getByName(GROUP), PORT))
        } catch (_: Exception) {
            crewMutedByOperator = previous
            onStatus("Perintah mute Crew gagal dikirim")
        }
    }

    private fun captureLoop() {
        val samples = ShortArray(SAMPLES)
        var smooth = 0.0
        var previousSend = false
        while (running) {
            val count = recorder?.read(samples, 0, samples.size) ?: -1
            if (count <= 0) continue
            var energy = 0.0
            for (i in 0 until count) energy += samples[i].toDouble() * samples[i].toDouble()
            val rms = sqrt(energy / count)
            smooth = smooth * 0.7 + rms * 0.3
            val send = if (role == "OPERATOR") {
                if (smooth > 520.0) lastVoiceAt = System.currentTimeMillis()
                System.currentTimeMillis() - lastVoiceAt < 500
            } else crewTalking && !crewMutedByOperator
            if (send != previousSend) { onMicActivity(send); previousSend = send }
            if (send) {
                val pcm = ByteBuffer.allocate(count * 2).order(ByteOrder.LITTLE_ENDIAN)
                for (i in 0 until count) {
                    val boosted = (samples[i].toInt() * audioGain).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())
                    pcm.putShort(boosted.toShort())
                }
                sendPacket(pcm.array())
            }
        }
    }

    private fun sendPacket(pcm: ByteArray) {
        try {
            val nameBytes = deviceName.toByteArray(Charsets.UTF_8).take(48).toByteArray()
            val packet = ByteBuffer.allocate(16 + nameBytes.size + pcm.size).order(ByteOrder.BIG_ENDIAN)
            packet.putInt(MAGIC)
            packet.put(deviceId.toByteArray(Charsets.US_ASCII).copyOf(8))
            packet.put(if (role == "OPERATOR") 1.toByte() else 2.toByte())
            packet.put(nameBytes.size.toByte()) // panjang nama pengirim
            packet.putShort(pcm.size.toShort())
            packet.put(nameBytes)
            packet.put(pcm)
            val data = packet.array()
            socket?.send(DatagramPacket(data, data.size, InetAddress.getByName(GROUP), PORT))
        } catch (_: Exception) { }
    }

    private fun receiveLoop() {
        val buffer = ByteArray(1500)
        while (running) {
            try {
                val packet = DatagramPacket(buffer, buffer.size)
                socket?.receive(packet)
                if (packet.length < 16) continue
                val bb = ByteBuffer.wrap(packet.data, 0, packet.length).order(ByteOrder.BIG_ENDIAN)
                if (bb.int != MAGIC) continue
                val id = ByteArray(8); bb.get(id)
                if (String(id, Charsets.US_ASCII).trim('\u0000') == deviceId) continue
                val senderRole = bb.get().toInt()
                val nameLength = bb.get().toInt() and 0xff
                val length = bb.short.toInt() and 0xffff
                if (length <= 0 || nameLength > bb.remaining() || length > bb.remaining() - nameLength) continue
                val senderNameBytes = ByteArray(nameLength); bb.get(senderNameBytes)
                val senderName = String(senderNameBytes, Charsets.UTF_8).ifBlank { if (senderRole == 1) "OPERATOR" else "CREW" }
                if (senderRole == 3) {
                    val command = bb.get().toInt()
                    if (role == "CREW") {
                        crewMutedByOperator = command == 1
                        onStatus(if (crewMutedByOperator)
                            "$deviceName • Mikrofon dibisukan Operator"
                        else "$deviceName • Mikrofon diaktifkan Operator")
                    }
                    continue
                }
                val pcm = ByteArray(length); bb.get(pcm)
                player?.write(pcm, 0, pcm.size)
                lastSpeakerAt = System.currentTimeMillis()
                onSpeaker(senderName, true)
            } catch (e: java.net.SocketTimeoutException) {
                if (running && System.currentTimeMillis() - lastSpeakerAt > 700) onSpeaker("", false)
            } catch (_: Exception) {
                if (running) onStatus("Periksa router dan izin multicast")
            }
        }
    }

    fun stop() {
        running = false
        try { recorder?.stop(); recorder?.release() } catch (_: Exception) {}
        try { player?.stop(); player?.release() } catch (_: Exception) {}
        try { socket?.leaveGroup(InetAddress.getByName(GROUP)); socket?.close() } catch (_: Exception) {}
        try { multicastLock?.release() } catch (_: Exception) {}
    }
}
