plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.redintercom.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.redintercom.app"
        minSdk = 26
        targetSdk = 28
        versionCode = 3
        versionName = "1.1-audio-indicator"
    }
}
