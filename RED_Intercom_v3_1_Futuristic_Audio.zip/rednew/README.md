# RED Intercom - Prototype LAN Audio

Android project for local Wi-Fi intercom. Internet is not needed for audio operation; all devices must be connected to the same Wi-Fi router and the router must permit multicast UDP.

## Included in this revision
- RD logo in the app.
- Operator VOX (voice threshold) and Crew push-to-talk.
- Operator command to mute/unmute Crew microphones.
- On-screen microphone state (transmit active / standby).
- Incoming speaker label based on device name included in the audio packet.
- Incoming audio activity indicator and idle state.
- AudioTrack output volume set to the Android API maximum, plus adjustable transmit gain (1.0x–2.0x) with clipping protection.

## Audio limitations
- The app cannot exceed the physical speaker or Android system-volume limits. Set the phone's media/call volume high manually.
- Gain boost may cause clipping/distortion when input is already loud. Start low and raise gradually.
- This is a prototype, not a production-ready emergency or mission-critical communication system. Test on your specific phones/router.
- Multicast UDP may be blocked by some routers or phone Wi-Fi implementations.
- Advanced DSP such as full AGC, compressor, EQ, and noise suppression are not implemented in this build.

## Build
Open this project in Android Studio or use the included GitHub Actions workflow from the repository.
