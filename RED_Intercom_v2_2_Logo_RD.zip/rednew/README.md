# RED Intercom v2 — Android Studio prototype

## Fitur
- Logo RD pengguna disertakan dengan latar putih transparan.
- Nama Crew dapat diubah sebelum memulai interkom dan disimpan di perangkat.
- Satu perangkat memilih OPERATOR: VOX mengirim audio otomatis ketika terdeteksi suara, diam = mute.
- Perangkat lain memilih CREW: tekan dan tahan tombol untuk bicara.
- Semua perangkat dalam satu Wi-Fi router menerima audio multicast.
- Router tidak memerlukan koneksi internet.

## Menjalankan
1. Ekstrak ZIP dan buka folder `RED_Intercom_Android_v2` di Android Studio.
2. Tunggu Gradle Sync selesai.
3. Sambungkan semua HP Android ke SSID router yang sama.
4. Pastikan router tidak mengaktifkan AP/client isolation dan mengizinkan multicast.
5. Jalankan aplikasi, izinkan mikrofon, pilih peran dan isi nama perangkat, lalu tekan MULAI INTERCOM.
6. Gunakan satu Operator dan maksimal empat Crew.

## Batasan penting
Ini masih prototipe pengujian, bukan APK produksi. UDP multicast dapat diblokir oleh beberapa router. Ambang VOX masih nilai awal dan harus diuji/diatur di lokasi. Audio belum dienkripsi atau diautentikasi. Belum ada foreground service untuk operasi layar mati, manajemen giliran bicara Crew, pembatalan echo, atau pengujian lintas perangkat. Gunakan headset saat uji awal untuk mencegah feedback akustik. Build APK perlu dilakukan di Android Studio.


## Fitur tambahan v2.1
- Tampilan utama Operator memiliki tombol `MUTE SEMUA CREW`.
- Operator dapat mengaktifkan kembali mikrofon Crew dari tombol yang sama.
- Perintah mute/unmute dikirim sebagai paket kontrol melalui jaringan lokal.
- Crew tetap dapat mendengar audio Operator saat mikrofonnya dibisukan.

Logo aplikasi diperbarui memakai logo RD yang diberikan pengguna (background putih dibuat transparan) dan dipakai sebagai ikon launcher.

Catatan: indikator pembicara real-time antarperangkat belum diimplementasikan pada paket ini. Untuk mendeteksi nama perangkat yang benar-benar sedang mengirim audio, protokol audio perlu ditambah event speaker dan diuji di router/ponsel nyata.
